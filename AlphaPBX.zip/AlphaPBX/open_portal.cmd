@echo off
setlocal EnableExtensions

set "RAW=%~1"
if "%RAW%"=="" exit /b 0

"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -Command ^
  "$raw = '%RAW%';" ^
  "$raw = [string]$raw;" ^
  "$caller = $null;" ^
  "$m = [regex]::Match($raw,'(01\d{9})');" ^
  "if($m.Success){ $caller=$m.Groups[1].Value }" ^
  "if(-not $caller){" ^
  "  $m2=[regex]::Match($raw,'\+?880(1\d{9})');" ^
  "  if($m2.Success){ $caller='0'+$m2.Groups[1].Value }" ^
  "}" ^
  "if(-not $caller){" ^
  "  $m3=[regex]::Match($raw,'\b(\d{2,6})\b');" ^
  "  if($m3.Success){ $caller=$m3.Groups[1].Value }" ^
  "}" ^
  "if(-not $caller){ exit 0 }" ^
  "$url = 'https://demo1.crm.com.bd/admin/unified_phone/search?calltype=incoming&phone=' + $caller;" ^
  "Start-Process -FilePath $url;" ^
  1>nul 2>nul

endlocal
exit /b 0